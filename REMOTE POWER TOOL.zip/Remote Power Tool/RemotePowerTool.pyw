from flask import Flask, request, render_template_string
import os

app = Flask(__name__)

# Directory containing this script
BASE_RUN_FOLDER = os.path.dirname(os.path.abspath(__file__))

HTML_TEMPLATE = '''
<!doctype html>
<html>
<head>
    <title>Remote PC Power Control</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      body { font-family: sans-serif; text-align: center; background: #1e1e1e; color: white; padding: 40px; }
      button { width: 90%; max-width: 300px; padding: 15px; margin: 10px; font-size: 18px; background-color: #0a92e4; color: white; border: none; border-radius: 10px; cursor: pointer; }
      h2 { margin-bottom: 30px; }
    </style>
</head>
<body>
    <h2>Remote PC Power Control</h2>
    <form method="POST" action="/action">
        <button name="action" value="shutdown">Shutdown</button><br>
        <button name="action" value="restart">Restart</button><br>
        <button name="action" value="lock">Lock</button><br>
        <button name="action" value="logoff">Log Off</button><br>
        <button name="action" value="screenoff">Turn Off Screen</button><br>
        <button name="action" value="sleep">Sleep</button><br>
        <button name="action" value="custom">Run Custom Script</button><br>
        <button name="action" value="stop">Stop Remote Control</button>
    </form>
</body>
</html>
'''

@app.route('/', methods=['GET'])
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/action', methods=['POST'])
def action():
    act = request.form.get('action')

    if act == 'shutdown':
        os.system('shutdown /s /t 0')
        return 'Shutting down...', 200

    if act == 'restart':
        os.system('shutdown /r /t 0')
        return 'Restarting...', 200

    if act == 'lock':
        os.system('rundll32.exe user32.dll,LockWorkStation')
        return 'Locking...', 200

    if act == 'logoff':
        os.system('shutdown /l')
        return 'Logging off...', 200

    if act == 'screenoff':
        nircmd = os.path.join(BASE_RUN_FOLDER, 'nircmd.exe')
        os.system(f'"{nircmd}" monitor off')
        return 'Screen off...', 200

    if act == 'sleep':
        os.system('rundll32.exe powrprof.dll,SetSuspendState 0,1,0')
        return 'Sleeping...', 200

    if act == 'custom':
        batch = os.path.join(BASE_RUN_FOLDER, 'Custom_Script.vbs')
        os.system(f'start "" "{batch}"')
        return 'Running custom script...', 200

    if act == 'stop':
        # call your kill script (which taskkills pythonw.exe)
        kill_bat = os.path.join(BASE_RUN_FOLDER, 'kill_flask.bat')
        os.system(f'start "" "{kill_bat}"')
        return 'Stopping Remote Power Tool...', 200

    return 'Invalid action.', 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
