@echo off
setlocal

:: 1) Try to find pythonw.exe on the system
for /f "delims=" %%P in ('where pythonw.exe 2^>nul') do set "PYTHONW=%%P"

:: 2) Fallback to common install paths if needed
if not defined PYTHONW if exist "%LocalAppData%\Programs\Python\Python313\pythonw.exe" set "PYTHONW=%LocalAppData%\Programs\Python\Python313\pythonw.exe"
if not defined PYTHONW if exist "C:\Python313\pythonw.exe" set "PYTHONW=C:\Python313\pythonw.exe"

:: 3) Error out if still not found
if not defined PYTHONW (
  echo ERROR: pythonw.exe not found. Please install Python or add pythonw.exe to your PATH.
  pause
  exit /b 1
)

:: 4) Point at your RemotePowerTool.pyw (adjust the path if your folder differs)
set "SCRIPT=%~dp0Remote Power Tool\RemotePowerTool.pyw"
if not exist "%SCRIPT%" (
  echo ERROR: Cannot find RemotePowerTool.pyw at "%SCRIPT%".
  pause
  exit /b 1
)

:: 5) Launch it hidden
start "" "%PYTHONW%" "%SCRIPT%"

echo ✅ Remote Power Tool started!
pause
endlocal